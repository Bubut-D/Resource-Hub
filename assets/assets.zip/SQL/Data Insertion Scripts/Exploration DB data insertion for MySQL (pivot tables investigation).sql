INSERT INTO `shopping`
(
    `sh_id`,
    `sh_transaction`,
    `sh_category`
) VALUES
(1, 1, 'Bag'),
(2, 1, 'Dress'),
(3, 1, 'Bag'),
(4, 2, 'Bag'),
(5, 2, 'Skirt'),
(6, 3, 'Dress'),
(7, 3, 'Skirt'),
(8, 3, 'Shoes'),
(9, 3, 'Hat'),
(10, 4, 'Bag');